# STELLAR DESCENT – Military 9‑Slice Buttons

RGBA PNG, mobile‑first, utilitarian military UI buttons.

Asset size: 512×192
Insets: L/R 96px, T/B 64px

Use with CSS border-image (9‑slice).