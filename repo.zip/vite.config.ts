import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";
import { vitePlugins } from "./vite/plugin";
import { resolve } from "path";

function pathResolve(dir: string) {
  return resolve(__dirname, ".", dir);
}

// https://vitejs.dev/config/
export default ({ mode }: any) => {
  const root = process.cwd();
  const env = loadEnv(mode, root);
  return defineConfig({
    base: env.VITE_PUBLIC_PATH,
    root,
    // plugin
    plugins: [react(), ...vitePlugins(env)],
    // alias
    resolve: {
      alias: {
        "@": pathResolve("src"),
      },
      extensions: [".js", ".ts", ".tsx", ".json"],
    },
    esbuild: {
      pure: mode === "production" ? ["console.log"] : [],
    },
    server: {
      host: '0.0.0.0',
      port: 8080,
      open: false,
      hmr: true,
      cors: true,
    },
    build: {
      target: "esnext",
      outDir: "dist",
      chunkSizeWarningLimit: 550,
      assetsInlineLimit: 4096,
      rollupOptions: {
        output: {
          chunkFileNames: "static/js/[name]-[hash].js",
          entryFileNames: "static/js/[name]-[hash].js",
          assetFileNames: "static/[ext]/[name]-[hash].[ext]",
        },
      },
    },
    optimizeDeps: {
      exclude: ["@babylonjs/havok"],
    },
  });
};
