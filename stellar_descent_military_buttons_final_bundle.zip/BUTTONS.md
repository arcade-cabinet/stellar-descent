# STELLAR DESCENT – Military 9-Slice Buttons (Final)

This bundle contains **four individually rendered button states**, each with:
- Identical geometry
- Identical text-safe inner region
- Distinct surface coloration and lighting per state

## States
- **Normal** – Neutral olive, operational
- **Hover** – Warmer olive, brighter brass highlights
- **Pressed** – Cooler/darker olive with inner perimeter shadow (no scaling)
- **Disabled** – Desaturated gray-green, oxidized frame

## 9-Slice Insets
- Left / Right: 96px
- Top / Bottom: 64px

## Usage (CSS)
```css
.militaryBtn {
  border: 32px solid transparent;
  border-image-source: var(--btn-src);
  border-image-slice: 64 96 64 96 fill;
  border-image-width: 32px;
  border-image-repeat: stretch;
  background: transparent;
  min-height: 44px;
}
```

## Notes for Agents
- Do NOT scale inner content between states
- Use color/state swap only
- Safe for mobile-first layouts
