# STELLAR DESCENT – Military 9-Slice Buttons (v1.1)

Pressed state uses **true inner bevel**:
- edge compression
- micro-shadow inset
- reduced luminance for physical depth

No opacity-based states. Mobile-safe.

Asset size: 512×192
Insets: L/R 96px, T/B 64px
